# おせろ

A Pen created on CodePen.

Original URL: [https://codepen.io/yaudakxf-the-bashful/pen/dywzpXR](https://codepen.io/yaudakxf-the-bashful/pen/dywzpXR).

